<template>
  <div id="cabrio">
      <h2>Cabrio</h2>
      <hr>
  <p>Hello!</p>
  </div>
</template>

<script>
export default{
   	components: {
		//
    },
    data(){  
         return {     
            apiUrl: this.$store.state.apiUrl,
            apiKey: this.$store.state.apiKey,
         }
    },
    methods: {
        callApi(handleResponse, url){
            this.axios.get(url).then((response) => {
                handleResponse(response.data)                      
            })
        },
        pullCarClasses(){
            this.callApi(this.renderClasses, this.apiUrl + '/classes?bodyId=5&apikey='+this.apiKey)     
        },
        renderCarClasses(data){
            data.forEach(element => {          

            });
        },      
    }
}
</script>

<style scoped>
</style>