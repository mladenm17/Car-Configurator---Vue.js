<template>
    <div id="hatchback" class="clearfix">
      <h2>-Hatchback-   </h2>
      <hr>
        <div class="tiles" v-for="item in classes" :key="item.id" :style="{'background-image': imageUrl}">
            <h4>{{item.name}}</h4>
            <p>Initial price: {{item.price}} euro</p>
            <p></p>
            <p class="configureTitle">Configure one of the available models: </p>
            <ul class="clearfix">
                <li v-for="modelName in item.models[0]" :key="modelName.id">
                    <a>{{modelName.shortName}} </a> 
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default{
    data(){  
         return {     
            apiUrl: this.$store.state.apiUrl,
            apiKey: this.$store.state.apiKey,
            classes: [],    
            imageUrl: "",
            price: ""
         }
    },
    methods: {
        callApi(handleResponse, url){
            this.axios.get(url).then((response) => {
                handleResponse(response.data)                      
            })
        },
        //i am calling this.callApi externally, so i had to wrapp it in pullCarClasses method name
        //that is why all other methods starts with "render" prefix, except this starting one
        pullCarClasses(){
            this.callApi(this.renderCarClasses, this.apiUrl + '/classes?bodyId=13&apikey='+this.apiKey)           
        },
        renderCarClasses(data){   
            var newData = data.slice(0);
            if(newData.length > 3) data.length = 3
            newData.forEach(element => {          
                this.classes.push({'name': element.className, 'models': []})   
                this.callApi(this.renderCarModels, element._links.models)          
            });         
        }, 
        renderCarModels(data){  
            if(data.length > 5) data.length = 5 
            this.classes[0].models.push(data)   
            //this.classes[0].push({'price' : 'asds'})
            //we get related request link for vehicle configuration from API, so we use that   
            this.callApi(this.renderCarConfigurations, data[0]._links.configurations)                             
        },   
        renderCarConfigurations(data){ 
            //we get related request link for vehicle image from API, so we use that   
             this.callApi(this.renderCarImages, data._links.image)  
        },
        renderCarImages(data){
            //we get related request link for vehicle image from API, so we use that   
            this.imageUrl = "url('"+data.vehicle.EXT020.url+"')"
        },
    }
}
</script>

<style scoped>
.clearfix{
    clear: both;
}
#hatchback{
    height: auto;
    background: transparent url('../assets/images/HDLogoBg.jpg') no-repeat center center;
    background-size: cover;
}
h2{
    text-align: center; 
}
.tiles{
    padding: 8px 20px;
    width: 33%;
    float: left;
    background-position: -86px -40px;
    background-size: 703px;
    background-repeat: no-repeat;
}
.configureTitle{
    margin-top: 215px;
    text-align: center;
}
ul{
    list-style: none;
    padding-left: 0px;
    width: 100%;
    border-top: 1px solid white;
}
ul li{
    float: left; 
    text-align: left;
    width: 158px;
    margin: 8px 0px;
    border-left: 1px solid gray;
    padding-left: 9px;
}
ul li:hover{
    cursor: pointer;
    color: white;
    background:rgb(204, 200, 200)
}
</style>