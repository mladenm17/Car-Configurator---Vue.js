<template>
  <div class="container-fluid">
    <header class="page-header">                
        <a href="index.html">
        <img class="headerBackground" src="../assets/images/mercedesTransparentLogo.png"/>
        </a> 
        <h1 class="gillSans">Configure your car</h1>
    </header>
    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-white">    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <!-- dinamicki ubaciti href -->
                <a class="nav-item nav-link" href="#hatchback" v-for="item in menuItems" :value="item.id" :key="item.bodyId">
                    {{item.name}}       
                </a>
            </div>
        </div>
    </nav>       
    <div class="row">         
        <div class="col-lg-12">    
            <template>
                <rotatingSign/> 
            </template>
            <template>
                <hatchback ref="hatchbackRef"/>           
            </template>
            <template>
                <suv ref="suvRef"/>          
            </template>
            <template>
                <div id="limousine">
                    <limousine ref="limousineRef"/>
                </div>            
            </template>
            <template>
                <div id="estate">
                    <estate ref="estateRef"/>
                </div>            
            </template>
            <template>
                <div id="cabriolet">
                    <cabriolet ref="cabrioletRef"/>
                </div>            
            </template>
            <template>
                <div id="coupe">
                    <coupe ref="coupeRef"/>
                </div>            
            </template>
        </div>
     
    </div>
  </div>
</template>

<script>
import rotatingSign from '../components/rotatingSign'
import hatchback from '../components/hatchback'
import suv from '../components/SUV'
import limousine from '../components/limousine'
import estate from '../components/estate'
import cabriolet from '../components/cabrio'
import coupe from '../components/coupe'

export default{
   	components: {
		rotatingSign, hatchback, suv, limousine, estate, cabriolet, coupe
	},
    data(){  
         return {
            toolTop: "Close menu",          
            menuItems: [{}],
            startPage: true,
            classesPage: false,
            apiUrl: this.$store.state.apiUrl,
            apiKey: this.$store.state.apiKey
         }
    },
    mounted() {      
        this.pullCarBodies()
        this.$refs.hatchbackRef.pullCarClasses() 
        this.$refs.suvRef.pullCarClasses()
        //this.$refs.limousine.pullClasses()
        //this.$refs.estate.pullClasses()
        //this.$refs.cabriolet.pullClasses()
        //this.$refs.coupe.pullClasses()
    },
    methods : {  
        openCloseNav(){
            this.$refs.button.classList.toggle('is-active');
            this.$refs.menuItems.classList.toggle('closed');    
            if(this.$refs.button.classList.contains('is-active'))
            this.toolTop = "Close menu"
            else{this.toolTop = "Expand menu"}    
        },  
        callApi(handleResponse, url){
            this.axios.get(url).then((response) => {
                handleResponse(response.data)                      
            })
        }, 
        pullCarBodies(){
           this.callApi(this.renderCarBodies, this.apiUrl + '/bodies?&apikey='+this.apiKey)
        },   
        renderCarBodies(data){
            data.forEach(element => {
                if(element.bodyId == 1 || element.bodyId == 3 || element.bodyId == 5 || element.bodyId == 6 || element.bodyId == 13 || element.bodyId == 16){
                this.menuItems.push({'id': element.bodyId, 'name': element.bodyName})
                }
            });
        }   
    }
}
</script>

<style scoped>
.reset{
    margin: 0px;
    padding: 0px;
}
body{
    background-color:gainsboro;
}
h1{
    margin-right: 108px;
}
.clearfix{
    clear: both;
}
.container-fluid{
    background-color: white;
    height: 1000px;
}
.page-header{  
    height: 145px;
    width: 100%;
    border-bottom:1px solid black;
    text-align: center;
    margin-top: 20px;
}
.headerBackground{
    width: 120px;
    float: left;
    margin: 20px 0px 0px 15px;
}   
.gillSans{
    font-family: "Gill Sans", sans-serif;
    font-weight: 100;
    color: black;
    font-size: 90px;
  
}
.navbar-nav{
    margin: 0 auto !important;
}
.nav-item{
    margin-right: 15px !important;
    font-size: 20px;
    color: black !important;
}
.nav-item:hover{
    background: white !important;
    border-bottom: 1px solid black;  
}
.hatchback{
    background-color: lightgray;
}
.closed{
    width: 40px;
    height: 35px;
}
@media (max-height: 618px) {
    .sideNav li{
        font-size: 14px;    
        padding: 3px 15px;
        }
}
@media (max-height: 400px) {
    .sideNav li{
        font-size: 10px;    
        padding: 1px 15px;
        } 
}
</style>