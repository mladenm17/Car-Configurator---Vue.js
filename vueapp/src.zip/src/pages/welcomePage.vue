<template >
   <div class="container-fluid">
        <button class="btnButton btnViewOrders" type="button">View orders</button>
        <router-link to="/order">
            <button class="btnButton btnConfigureCar">Configure car</button>
        </router-link>
   </div>
</template>

<script>
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container-fluid{
    height: 950px;
    background: transparent url("../assets/images/orderMercedes.jpg") no-repeat ;
    background-size: cover; 
    padding: 0px;
}
.btnButton{
    position: absolute;
    bottom: 50%;
    padding: 40px 150px;
    background: black url("../assets/images/mercedesLogo.jpg") no-repeat;
    background-size: 110px;
    border-color:  #a8b5be;
    opacity: 0.6;
    transition: 0.8s;
    color: whitesmoke;
}
.btnButton:hover{
    box-shadow: 0 12px 16px 0 black, 0 17px 50px 0 black;
    opacity: 1;
    cursor: pointer;
}
.btnButton:after{
    content: "";
    background: #f1f1f1;
    display: block;
    position: absolute;
    padding: 0;
    margin: 0;
    opacity: 1;
    transition: all 0.8s;
}
.btnButton:hover:after{
    padding-top: 28%;
    padding-left: 100%;
    margin-left: -150px;
    margin-top: -18%;  
    opacity: 0;
    transition: 1s;
}
.btnConfigureCar{
    left: 20%;
}
.btnViewOrders{
    right: 20%;
}   
</style>
